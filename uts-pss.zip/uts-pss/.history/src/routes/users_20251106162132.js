const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/usersController');

router.get('/', ctrl.list);
router.get('/new', ctrl.newForm);
router.post('/', ctrl.create);
router.get('/:id/edit', ctrl.editForm);
router.post('/:id?_method=PUT', ctrl.update);
router.post('/:id/delete?_method=DELETE', ctrl.remove);

module.exports = router;
